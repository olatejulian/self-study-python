# Python Seedwork

Clean arch and design patterns prototypes
